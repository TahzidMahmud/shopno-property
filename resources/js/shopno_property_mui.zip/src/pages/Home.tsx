import React, { useContext, useState } from 'react'
import { Grid } from '@mui/material'
import PropertyCard from '../components/PropertyCard'
import { PropertyContext } from '../context/PropertyContext'
import PropertyDetailDialog from '../components/PropertyDetailDialog'

export default function Home() {
  const { properties } = useContext(PropertyContext)
  const [openId, setOpenId] = useState<number | null>(null)

  return (
    <>
      <Grid container spacing={2}>
        {properties.map(p => (
          <Grid item xs={12} sm={6} md={4} key={p.id}>
            <PropertyCard property={p} onOpen={(id) => setOpenId(id)} />
          </Grid>
        ))}
      </Grid>

      <PropertyDetailDialog
        open={openId !== null}
        id={openId}
        onClose={() => setOpenId(null)}
      />
    </>
  )
}
