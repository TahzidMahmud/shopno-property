export type Property = {
  id: number
  title: string
  description: string
  price: number
  image: string
}
