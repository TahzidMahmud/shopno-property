import React from 'react';
import { Navigate } from 'react-router-dom';
import { Box, Typography, Container } from '@mui/material';
import { useAuth } from '../contexts/AuthContext';
import ProtectedRoute from '../components/ProtectedRoute';
import PropertiesManagement from './admin/PropertiesManagement';

const ListProperty: React.FC = () => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <Box
        sx={{
          minHeight: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Typography>Loading...</Typography>
      </Box>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/admin/login" state={{ from: { pathname: '/list-property' } }} replace />;
  }

  return (
    <ProtectedRoute>
      <Container maxWidth="xl" sx={{ py: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          List Your Property
        </Typography>
        <PropertiesManagement />
      </Container>
    </ProtectedRoute>
  );
};

export default ListProperty;


