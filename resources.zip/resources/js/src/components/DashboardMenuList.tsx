import * as React from 'react';
import { styled, Theme, CSSObject } from '@mui/material/styles';
import MuiDrawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import {
  Dashboard as DashboardIcon,
  Home as HomeIcon,
  Business as BusinessIcon,
  Category as CategoryIcon,
  People as PeopleIcon,
  Settings as SettingsIcon,
  Pool as PoolIcon,
  Web as WebIcon,
  Menu as MenuIcon,
  Assignment as AssignmentIcon,
  Security as SecurityIcon,
} from '@mui/icons-material';
import { useNavigate, useLocation } from 'react-router-dom';

const drawerWidth = 240;

const openedMixin = (theme: Theme): CSSObject => ({
  width: drawerWidth,
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: 'hidden',
});

const closedMixin = (theme: Theme): CSSObject => ({
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: 'hidden',
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up('sm')]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
});

const DrawerHeader = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'flex-end',
  padding: theme.spacing(0, 1),
  ...theme.mixins.toolbar,
}));

const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
  ({ theme, open }) => ({
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: 'nowrap',
    boxSizing: 'border-box',
    ...(open && {
      ...openedMixin(theme),
      '& .MuiDrawer-paper': openedMixin(theme),
    }),
    ...(!open && {
      ...closedMixin(theme),
      '& .MuiDrawer-paper': closedMixin(theme),
    }),
  }),
);

interface DashboardMenuListProps {
  open: boolean;
  handleDrawerClose: () => void;
  theme: Theme;
}

const menuItems = [
  { text: 'Dashboard', icon: <DashboardIcon />, path: '/admin/dashboard' },
  { text: 'Properties', icon: <HomeIcon />, path: '/admin/dashboard/properties' },
  { text: 'Facilities', icon: <PoolIcon />, path: '/admin/dashboard/facilities' },
  { text: 'Home Page Management', icon: <WebIcon />, path: '/admin/dashboard/homepage' },
  { text: 'Header & Footer', icon: <MenuIcon />, path: '/admin/dashboard/header-footer' },
  { text: 'Contact Page', icon: <WebIcon />, path: '/admin/dashboard/contact-page' },
  { text: 'About Page', icon: <WebIcon />, path: '/admin/dashboard/about-page' },
  { text: 'Projects Page', icon: <WebIcon />, path: '/admin/dashboard/projects-page' },
  { text: 'Partner Submissions', icon: <AssignmentIcon />, path: '/admin/dashboard/partner-submissions' },
  { text: 'Property Queries', icon: <AssignmentIcon />, path: '/admin/dashboard/property-queries' },
  { text: 'Contact Enquiries', icon: <AssignmentIcon />, path: '/admin/dashboard/contact-enquiries' },
  { text: 'Users', icon: <PeopleIcon />, path: '/admin/dashboard/users' },
  { text: 'Roles', icon: <SecurityIcon />, path: '/admin/dashboard/roles' },
  { text: 'Companies', icon: <BusinessIcon />, path: '/admin/dashboard/companies' },
  { text: 'Property Types', icon: <CategoryIcon />, path: '/admin/dashboard/property-types' },
  { text: 'Settings', icon: <SettingsIcon />, path: '/admin/dashboard/settings' },
];

export default function DashboardMenuList({ open, handleDrawerClose, theme }: DashboardMenuListProps) {
  const navigate = useNavigate();
  const location = useLocation();

  const handleMenuClick = (path: string) => {
    navigate(path);
  };

  return (
    <Drawer variant="permanent" open={open}>
      <DrawerHeader>
        <IconButton onClick={handleDrawerClose}>
          {theme.direction === 'rtl' ? <ChevronRightIcon /> : <ChevronLeftIcon />}
        </IconButton>
      </DrawerHeader>
      <Divider />
      <List>
        {menuItems.map((item) => (
          <ListItem key={item.text} disablePadding sx={{ display: 'block' }}>
            <ListItemButton
              onClick={() => handleMenuClick(item.path)}
              selected={location.pathname === item.path}
              sx={{
                minHeight: 48,
                justifyContent: open ? 'initial' : 'center',
                px: 2.5,
              }}
            >
              <ListItemIcon
                sx={{
                  minWidth: 0,
                  mr: open ? 3 : 'auto',
                  justifyContent: 'center',
                }}
              >
                {item.icon}
              </ListItemIcon>
              <ListItemText primary={item.text} sx={{ opacity: open ? 1 : 0 }} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
      <Divider />
    </Drawer>
  );
}
